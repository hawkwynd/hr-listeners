
-- --------------------------------------------------------

--
-- Structure for view `world_total_listeners_by_country`
--
DROP TABLE IF EXISTS `world_total_listeners_by_country`;

CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `world_total_listeners_by_country`  AS  select `c`.`printable_name` AS `country`,count(`l`.`country`) AS `visits` from (`listeners` `l` join `country` `c` on(`c`.`iso` = `l`.`country`)) group by `l`.`country` order by count(`l`.`country`) desc ;
