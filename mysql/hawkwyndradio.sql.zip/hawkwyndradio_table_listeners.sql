
-- --------------------------------------------------------

--
-- Table structure for table `listeners`
--

CREATE TABLE `listeners` (
  `id` int(11) NOT NULL,
  `hostname` varchar(45) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `first_connect` datetime DEFAULT NULL,
  `connecttime` time NOT NULL,
  `country` varchar(45) NOT NULL,
  `lat` float(10,6) NOT NULL,
  `lng` float(10,6) NOT NULL,
  `referer` varchar(12) NOT NULL,
  `state` varchar(45) DEFAULT NULL,
  `timestamp` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `disconnect` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `useragent` text NOT NULL,
  `status` int(11) DEFAULT 0,
  `connections` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
