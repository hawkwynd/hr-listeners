
-- --------------------------------------------------------

--
-- Structure for view `listeners_yesterday`
--
DROP TABLE IF EXISTS `listeners_yesterday`;

CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `listeners_yesterday`  AS  select `listeners`.`city` AS `city`,`listeners`.`state` AS `state`,`listeners`.`country` AS `country`,`c`.`printable_name` AS `pretty_country`,`listeners`.`connecttime` AS `connecttime`,`listeners`.`disconnect` AS `disconnect`,`listeners`.`referer` AS `referer`,`listeners`.`timestamp` AS `TIMESTAMP` from (`listeners` left join `country` `c` on(`c`.`iso` = `listeners`.`country`)) where time_format(`listeners`.`connecttime`,'%i') > 1 and `listeners`.`timestamp` between cast(curdate() as date) - interval 1 day and cast(curdate() as date) - interval 1 second ;
