
-- --------------------------------------------------------

--
-- Structure for view `listeners_timestamp`
--
DROP TABLE IF EXISTS `listeners_timestamp`;

CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `listeners_timestamp`  AS  select `listeners`.`hostname` AS `hostname`,`listeners`.`city` AS `city`,`listeners`.`state` AS `state`,`c`.`printable_name` AS `country`,`listeners`.`timestamp` AS `timestamp`,`listeners`.`connecttime` AS `connecttime`,`listeners`.`status` AS `status` from (`listeners` left join `country` `c` on(`listeners`.`country` = `c`.`iso`)) where 1 order by `listeners`.`timestamp` desc ;
