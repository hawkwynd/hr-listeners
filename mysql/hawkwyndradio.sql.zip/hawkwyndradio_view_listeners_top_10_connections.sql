
-- --------------------------------------------------------

--
-- Structure for view `listeners_top_10_connections`
--
DROP TABLE IF EXISTS `listeners_top_10_connections`;

CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `listeners_top_10_connections`  AS  select `listeners`.`city` AS `city`,`listeners`.`state` AS `state`,`c`.`printable_name` AS `country`,`listeners`.`connecttime` AS `connecttime`,`listeners`.`timestamp` AS `timestamp`,`listeners`.`referer` AS `referer` from (`listeners` left join `country` `c` on(`listeners`.`country` = `c`.`iso`)) where `listeners`.`timestamp` between curdate() - interval 1 month and curdate() order by `listeners`.`connecttime` desc limit 10 ;
