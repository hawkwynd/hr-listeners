
-- --------------------------------------------------------

--
-- Structure for view `top-10-countries-listeners`
--
DROP TABLE IF EXISTS `top-10-countries-listeners`;

CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `top-10-countries-listeners`  AS  select format(count(`l`.`country`),0) AS `listeners`,`c`.`name` AS `country` from (`listeners` `l` join `country` `c` on(`c`.`iso` = `l`.`country`)) where `l`.`timestamp` between curdate() - interval 1 month and curdate() group by `l`.`country` order by count(`l`.`country`) desc limit 0,10 ;
