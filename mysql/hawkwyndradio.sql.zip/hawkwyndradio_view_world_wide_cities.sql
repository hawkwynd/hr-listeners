
-- --------------------------------------------------------

--
-- Structure for view `world_wide_cities`
--
DROP TABLE IF EXISTS `world_wide_cities`;

CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `world_wide_cities`  AS  select distinct `listeners`.`city` AS `city`,`listeners`.`country` AS `country` from `listeners` where `listeners`.`city` <> 'null' and `listeners`.`country` in (select distinct `listeners`.`country` from `listeners`) order by `listeners`.`country` ;
