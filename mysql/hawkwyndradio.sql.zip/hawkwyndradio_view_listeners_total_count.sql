
-- --------------------------------------------------------

--
-- Structure for view `listeners_total_count`
--
DROP TABLE IF EXISTS `listeners_total_count`;

CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `listeners_total_count`  AS  select min(`listeners`.`timestamp`) AS `firstConnect`,max(`listeners`.`timestamp`) AS `lastConnect`,count(`listeners`.`hostname`) AS `totalListeners` from `listeners` ;
