
-- --------------------------------------------------------

--
-- Structure for view `listeners_last_month`
--
DROP TABLE IF EXISTS `listeners_last_month`;

CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `listeners_last_month`  AS  select `listeners`.`city` AS `city`,`listeners`.`state` AS `state`,`c`.`printable_name` AS `country`,`listeners`.`timestamp` AS `timestamp`,`listeners`.`connecttime` AS `connecttime`,`listeners`.`referer` AS `referer`,`listeners`.`disconnect` AS `disconnect` from (`listeners` left join `country` `c` on(`listeners`.`country` = `c`.`iso`)) where `listeners`.`timestamp` between date_format(current_timestamp() - interval 1 month,'%Y-%m-01 00:00:00') and date_format(last_day(current_timestamp() - interval 1 month),'%Y-%m-%d 23:59:59') order by `listeners`.`timestamp` desc ;
