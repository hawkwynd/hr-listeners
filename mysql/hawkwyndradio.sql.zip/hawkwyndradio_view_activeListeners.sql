
-- --------------------------------------------------------

--
-- Structure for view `activeListeners`
--
DROP TABLE IF EXISTS `activeListeners`;

CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `activeListeners`  AS  select `listeners`.`hostname` AS `hostname`,`listeners`.`city` AS `city`,`listeners`.`state` AS `state`,`listeners`.`country` AS `country`,`listeners`.`lat` AS `lat`,`listeners`.`lng` AS `lng`,`listeners`.`connecttime` AS `connecttime` from `listeners` where `listeners`.`disconnect` = '0000-00-00 00:00:00' order by `listeners`.`connecttime` desc ;
