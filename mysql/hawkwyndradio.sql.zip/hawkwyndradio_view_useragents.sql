
-- --------------------------------------------------------

--
-- Structure for view `useragents`
--
DROP TABLE IF EXISTS `useragents`;

CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `useragents`  AS  select distinct substr(substring_index(`listeners`.`useragent`,'/',1),1,40) AS `useragents` from `listeners` order by `listeners`.`useragent` ;
