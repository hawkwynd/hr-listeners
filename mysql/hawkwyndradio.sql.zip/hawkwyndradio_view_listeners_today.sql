
-- --------------------------------------------------------

--
-- Structure for view `listeners_today`
--
DROP TABLE IF EXISTS `listeners_today`;

CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `listeners_today`  AS  select `listeners`.`hostname` AS `hostname`,`listeners`.`first_connect` AS `fconnect`,`listeners`.`city` AS `city`,`listeners`.`state` AS `state`,`listeners`.`country` AS `country`,`listeners`.`connecttime` AS `duration`,`listeners`.`disconnect` AS `dtime`,`listeners`.`referer` AS `referer`,`listeners`.`timestamp` AS `timestamp`,`listeners`.`useragent` AS `useragent`,ifnull(`a`.`connection_count`,1) AS `connection_count`,ifnull(`a`.`timestamp`,`listeners`.`disconnect`) AS `last_time`,ifnull(`a`.`connecttime`,0) AS `connecttime`,`c`.`printable_name` AS `pretty_country` from ((`listeners` left join `analytics` `a` on(`a`.`id` = `listeners`.`id`)) left join `country` `c` on(`c`.`iso` = `listeners`.`country`)) where cast(`listeners`.`timestamp` as date) = curdate() and time_format(`listeners`.`connecttime`,'%i') > 1 order by `listeners`.`connecttime` desc ;
