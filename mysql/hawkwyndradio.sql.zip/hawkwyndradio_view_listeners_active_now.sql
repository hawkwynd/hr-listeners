
-- --------------------------------------------------------

--
-- Structure for view `listeners_active_now`
--
DROP TABLE IF EXISTS `listeners_active_now`;

CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `listeners_active_now`  AS  select `listeners`.`hostname` AS `hostname`,`listeners`.`timestamp` AS `timestamp`,`listeners`.`city` AS `city`,`listeners`.`first_connect` AS `first_connect`,`listeners`.`state` AS `state`,`c`.`printable_name` AS `country`,`listeners`.`referer` AS `referer`,`listeners`.`connecttime` AS `connecttime`,`listeners`.`disconnect` AS `disconnect`,`listeners`.`status` AS `status` from (`listeners` left join `country` `c` on(`listeners`.`country` = `c`.`iso`)) where `listeners`.`status` = 1 order by `listeners`.`connecttime` desc ;
