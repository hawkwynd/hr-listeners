
-- --------------------------------------------------------

--
-- Structure for view `listeners_countries`
--
DROP TABLE IF EXISTS `listeners_countries`;

CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `listeners_countries`  AS  select distinct `c`.`name` AS `name` from (`listeners` `l` left join `country` `c` on(`l`.`country` = `c`.`iso`)) where `c`.`name` is not null order by `c`.`name` ;
